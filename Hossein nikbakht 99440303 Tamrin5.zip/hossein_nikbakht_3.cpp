#include <iostream>
using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

//hossein_nikbakht
int word(char *p){
	int n=1;
	while(*p){
		if(*p==' ')
			n++;
		p++;
	}
	return n;
}
int main(int argc, char** argv) {
	char str[50];
	cout<<"Enter string: ";
	gets(str);
    cout<<"number of words = "<<word(str)<<endl;
        
    return 0; 
}
