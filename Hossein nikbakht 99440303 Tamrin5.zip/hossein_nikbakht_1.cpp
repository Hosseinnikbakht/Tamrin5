#include <iostream>
using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

//hossein_nikbakht
int main(int argc, char** argv) {
	int n;
	cout<<"Enter row number: ";
	cin>>n;
     int arr[n][n];
      for (int i = 0; i < n; i++)  
        for (int j = 0; j <= i; j++) { 
        if (i == j || j == 0) 
            arr[i][j] = 1; 
       
        else
            arr[i][j] = arr[i - 1][j - 1] +  arr[i - 1][j]; 
        } 
     
    for (int i = 0; i < n; i++) { 
        for (int j = 0; j <= i; j++) 
		 	cout << arr[i][j] << " "; 
		 cout << endl; 
	}
        
    return 0; 
}
