#include <iostream>
using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

//hossein_nikbakht
void table(int n,int m){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)
			cout<<i*j<<"\t";
		cout<<endl;
	}
}

int main(int argc, char** argv) 
{ 
	int n,m;
	cout<<"Enter 2 number: ";
	cin>>n>>m;
	table(n,m);
    return 0; 
}
